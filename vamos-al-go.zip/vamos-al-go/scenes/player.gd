extends CharacterBody2D

@export var velocidad: float = 120.0

func _physics_process(_delta):
	var direccion = Input.get_vector(
		"move_left",
		"move_right",
		"move_up",
        "move_down"
	)
	
	print(direccion)

	velocity = direccion * velocidad
	move_and_slide()
